from src.models.user import User


class Store:

    def __init__(self):
        self.bd = [
            User('Gabriel', 'Tester'),
            User('Beatriz', 'Developer'),
            User('Felipe', 'IT Specialist'),
            User('Juliana', 'QA'),
            User('Luana', 'Systems Analyst'),
            User('Eduardo', 'Software Developer'),
            User('Ricardo', 'Technical Support'),
            User('Isabela', 'Project Manager'),
            User('Thiago', 'DevOps'),
            User('Carolina', 'Designer'),
            User('André', 'Software Architect'),
            User('Patrícia', 'Product Owner'),
            User('Marcelo', 'Cybersecurity Specialist'),
            User('Sofia', 'Business Analyst'),
            User('João', 'Data Scientist'),
            User('Mariana', 'Front-end Developer')

        ]

